# # authentication/urls.py

# from django.urls import path

from . import views


# urlpatterns = [
#     # URLs will come here
# ]


# from dj_rest_auth.registration.views import RegisterView
from dj_rest_auth.views import LoginView, LogoutView, UserDetailsView
# from views import CustomLoginView
from django.urls import path


urlpatterns = [
    path("register/", views.RegisterView.as_view(), name="rest_register"),
    path("login/", LoginView.as_view(), name="rest_login"),
    path("logout/", LogoutView.as_view(), name="rest_logout"),
    path("user/", UserDetailsView.as_view(), name="rest_user_details"),
    path("all/users", views.all_users,name="get_all_users"),
    path('user/<int:pk>/delete', views.delete_user, name='delete-user')
    # path('account/confirm-email/<str:key>/', account_confirm_email, name='account_confirm_email'),

]