# from django.shortcuts import render
from django.contrib.auth.models import User
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .serializers import UserManagementSerializer, CustomRegisterSerializer
from django.shortcuts import get_object_or_404
from rest_framework import status
from dj_rest_auth.registration.views import RegisterView as BaseRegisterView

# Create your views here.

# views.py

# from dj_rest_auth.views import LoginView

# class CustomLoginView(LoginView):
#     pass

# from django.shortcuts import render

# def account_confirm_email(request, key):
#     # your view logic
#     pass


@api_view(['GET'])
def all_users(request):

    if request.query_params:
        floors = User.objects.filter(**request.query_params.dict())
    else:
        floors = User.objects.all()
    serializer = UserManagementSerializer(floors, many=True)
    context = {'data': serializer.data or {}, 'status': "OK"}
    return Response(context)


@api_view(['DELETE'])
def delete_user(request, pk):
    user = get_object_or_404(User, pk=pk)
    user.delete()
    return Response(status=status.HTTP_202_ACCEPTED)


class RegisterView(BaseRegisterView):
    serializer_class = CustomRegisterSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            self.perform_create(serializer)
            headers = self.get_success_headers(serializer.data)
            return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
