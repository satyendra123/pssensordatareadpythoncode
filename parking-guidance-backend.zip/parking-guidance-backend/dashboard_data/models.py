from django.db import models

from datetime import datetime
# Create your models here.


class ActivityLog(models.Model):
    id = models.AutoField(primary_key=True)
    floor_id = models.IntegerField(blank=True, null=True)
    zone_id = models.IntegerField(blank=True, null=True)
    sensor_id = models.IntegerField(blank=True, null=True)
    issue = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(blank=True, null=True)

    class Meta:
        db_table = 'activity_logs'


class Floor(models.Model):
    id = models.AutoField(primary_key=True)
    parking_name = models.CharField(max_length=255, blank=True, null=True)
    floor_id = models.IntegerField(blank=True, null=True)

    class Meta:
        db_table = 'floor'


class LineChart(models.Model):
    id = models.AutoField(primary_key=True)
    floor_id = models.IntegerField(blank=True, null=True)
    zone_id = models.IntegerField(blank=True, null=True)
    total_available = models.IntegerField(blank=True, null=True)
    total_vacant = models.IntegerField(blank=True, null=True)
    total_faulty = models.IntegerField(blank=True, null=True)

    class Meta:
        db_table = 'line_chart'


class Zone(models.Model):
    id = models.AutoField(primary_key=True)
    floor_id = models.IntegerField(blank=True, null=True)
    zone_id = models.IntegerField(blank=True, null=True)
    sensor_id = models.IntegerField(blank=True, null=True)

    class Meta:
        db_table = 'zone'
