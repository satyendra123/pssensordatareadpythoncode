
from django.urls import path
from . import views
 
urlpatterns = [
    path('statistics', views.get_dashboard_data, name='dashboard-data'),
    path('line-charts', views.get_dashboard_line_charts, name='dashboard-line-charts-data'),
    path('activity-logs', views.get_activity_logs, name='dashboard-activity-logs'),
    path('slot/24hours', views.get_slot_used_and_not_used, name='reports-url'),
]
