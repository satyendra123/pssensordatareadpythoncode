from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response
from sensors_data.models import Sensor
from django.db.models import Count
from .models import LineChart, ActivityLog
from .serializers import ActivityLogSerializer


@api_view(['GET'])
def get_dashboard_data(request):
    response = dict()
    distinct_floors = Sensor.objects.values('floor_id').distinct()
    for floor in distinct_floors:
        total_sensors = Sensor.objects.filter(floor_id=floor['floor_id']).count()
        total_vacant_count = Sensor.objects.filter(floor_id=floor['floor_id'], status=0).count()
        total_engaged_count = Sensor.objects.filter(floor_id=floor['floor_id'], status=1).count()
        total_faulty_count = Sensor.objects.filter(floor_id=floor['floor_id'], status=2).count()
        total_no_communication_count = Sensor.objects.filter(floor_id=floor['floor_id'], status=3).count()
        response[f"Basement {floor['floor_id']}"] = {
                    "total_slot": total_sensors,
                    "available_slot": total_vacant_count,
                    "engaged_slot": total_engaged_count,
                    'no_communication': total_no_communication_count,
                    "faulty": total_faulty_count
                }
    return Response(response)


@api_view(['GET'])
def get_dashboard_line_charts(request):
    distinct_floors = LineChart.objects.values('floor_id').distinct()
    response = dict()
    for floor in distinct_floors:
        # line_chart_count = LineChart.objects.filter(floor_id=floor['floor_id']).values('zone_id').annotate(order_count=Count('id'))
        line_chart_count = LineChart.objects.filter(floor_id=floor['floor_id']).order_by('id')[:5]
        response_basement = list(line_chart_count.values())
        for value in response_basement:
            value['total_occupied'] = value['total_available'] - value['total_vacant']
        response[f"Basement {floor['floor_id']}"] = response_basement
    return Response(response)


@api_view(['GET'])
def get_activity_logs(request):
    activity_logs_data = ActivityLog.objects.all()
    serializer = ActivityLogSerializer(activity_logs_data, many=True)
    return Response(
        {
            "data": serializer.data,
            "status": "OK"
        }
    )


@api_view(['GET'])
def get_slot_used_and_not_used(request):
    return Response(
        {
            "zone1": {
                "total": 27,
                "vacant": 12,
                "engaged": 15,
                "faulty": 0                
            },
            "zone2": {
                "total": 24,
                "vacant": 11,
                "engaged": 13,
                "faulty": 0                
            },
            "zone3": {
                "total": 24,
                "vacant": 17,
                "engaged": 7,
                "faulty": 0                
            },
            "zone4": {
                "total": 35,
                "vacant": 35,
                "engaged": 0,
                "faulty": 0                
            },
            "zone5": {
                "total": 21,
                "vacant": 21,
                "engaged": 0,
                "faulty": 0                
            },
            "cg": {
                "total": 22,
                "vacant": 22,
                "engaged": 0,
                "faulty": 0                
            },
        }
    )
