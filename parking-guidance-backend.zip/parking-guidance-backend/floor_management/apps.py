from django.apps import AppConfig


class FloorManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'floor_management'
