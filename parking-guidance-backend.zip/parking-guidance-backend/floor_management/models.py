from django.db import models

# Create your models here.

 
class FloorManagement(models.Model):
    floor_id = models.PositiveIntegerField()
    connected_parking = models.CharField(max_length=255)
    floor_name = models.CharField(max_length=255)
    total_slots = models.PositiveIntegerField(null=True)
    available = models.PositiveIntegerField(null=True)
    occupied = models.PositiveIntegerField(null=True)
    sensors = models.PositiveIntegerField(null=True)
    status = models.BooleanField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
 
    class Meta:
        db_table = "floor_management"

    def __str__(self) -> str:
        return self.connected_parking
