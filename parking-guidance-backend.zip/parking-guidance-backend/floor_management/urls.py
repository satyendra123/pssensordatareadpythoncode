
from django.urls import path
from . import views
 
urlpatterns = [
    # path('', views.ApiOverview, name='home'),
    path('create', views.add_floors, name='add-floors'),
    path('all', views.view_floors, name='view_floors'),
    path('update/<int:pk>', views.update_floors, name='update-floors'),
    path('floor/<int:pk>/delete', views.delete_floors, name='delete-floors'),
]
