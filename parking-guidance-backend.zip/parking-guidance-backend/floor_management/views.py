# from django.shortcuts import render

# # Create your views here.


from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import FloorManagement
from .serializers import (
    FloorManagementSerializer,
    CreateFloorSerializer
)

from rest_framework import serializers
from rest_framework import status
from django.shortcuts import get_object_or_404


@api_view(['POST'])
def add_floors(request):
    floor = CreateFloorSerializer(data=request.data)
 
    # validating for already existing data
    if FloorManagement.objects.filter(**request.data).exists():
        raise serializers.ValidationError('This data already exists')

    if floor.is_valid():
        floor.save()
        return Response(floor.data)
    else:
        return Response(status=status.HTTP_404_NOT_FOUND)


@api_view(['GET'])
def view_floors(request):

    if request.query_params:
        floors = FloorManagement.objects.filter(**request.query_params.dict())
    else:
        floors = FloorManagement.objects.all()
    serializer = FloorManagementSerializer(floors, many=True)
    context = {'data': serializer.data or {}, 'status': "OK"}
    return Response(context)


@api_view(['PATCH'])
def update_floors(request, pk):
    floor = FloorManagement.objects.get(pk=pk)
    data = FloorManagementSerializer(instance=floor, data=request.data)
     
    if data.is_valid():
        data.save()
        return Response(data.data)
    else:
        return Response(status=status.HTTP_404_NOT_FOUND)



@api_view(['DELETE'])
def delete_floors(request, pk):
    floor = get_object_or_404(FloorManagement, pk=pk)
    floor.delete()
    return Response(status=status.HTTP_202_ACCEPTED)