from django.db import models

# Create your models here.

class Sensor(models.Model):
    id = models.AutoField(primary_key=True)
    floor_id = models.IntegerField(blank=True, null=True)
    zone_id = models.IntegerField(blank=True, null=True)
    sensor_id = models.IntegerField(blank=True, null=True)
    status = models.CharField(max_length=1, blank=True, null=True)
    last_updated = models.DateTimeField(auto_now=True)
    count = models.IntegerField(blank=True, null=True)

    class Meta:
        unique_together = ('floor_id', 'zone_id', 'sensor_id')
        db_table = 'sensor'
