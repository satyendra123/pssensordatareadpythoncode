
from django.urls import path
from . import views
 
urlpatterns = [
    path('floor_id/<int:floor_id>/zone_id/<int:zone_id>', views.get_floor_zone_data, name='floor-zone-data')
]
