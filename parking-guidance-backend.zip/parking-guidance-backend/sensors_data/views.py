from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Sensor
from .serializers import SensorSerializer



@api_view(['GET'])
def get_floor_zone_data(request, floor_id, zone_id):
    floors = Sensor.objects.filter(floor_id=floor_id, zone_id=zone_id)

    serializer = SensorSerializer(floors, many=True)
    context = {'data': serializer.data or {}, 'status': "OK"}
    return Response(context)
